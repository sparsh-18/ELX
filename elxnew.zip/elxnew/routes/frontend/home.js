const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');

router.get("/",function(req,res) {
  
if(req.session.customer != undefined && req.session.customer!=null) {

   var query = "SELECT * FROM product LIMIT 8";
   con.query(query,function(err,respond) {
     if(err) throw err;
     var query  = "SELECT * FROM category";
     con.query(query,function(err,catdata) {
       if(err) throw err;
       con.query("SELECT * FROM banner", function(e, banner) {
         if(e) throw e;
         res.render("frontend/home",{data:respond, catdata:catdata, banner:banner});
       });
       
     });
   });
  } else  {
    res.redirect("/login");
  }
});
// router.get("/demo",function(req,res) {
//   res.render("frontend/demo");
// });
router.get("/allcategory",function(req,res) {
 
  con.query("SELECT * FROM product" , function(e, resp) {
    if(e) throw e;
    con.query("SELECT * FROM category", function(er, respC) {
      if(er) throw er;
      res.render("frontend/category", {productData: resp, catdata: respC});
    });
  });
 });

module.exports = router;