const express = require('express');
const configViewEngine = require("./configs/viewEngine");
var DBConnection = require("./configs/DBConnection");

var back = require('express-back');
const bodyParser = require("body-parser");
var session = require('express-session');
var cookieParser = require('cookie-parser');
// var passport = require('passport');
var connectFlash = require('connect-flash');
const upload = require('express-fileupload');
let app = express();
require('dotenv').config();
//use cookie parser
app.use(cookieParser('secret'));

var MySQLStore = require('express-mysql-session')(session);
var options = {
    host:'localhost',
    user:'root',
    password:"",
    database:"projectblog"
};

var sessionStore = new MySQLStore(options);

//config session
app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
        // maxAge: 1000 * 60 * 60 * 24 // 86400000 1 day
        secure: false
    }
}));


app.use(function(req, res, next) {
   res.locals.cart = req.session.cart;
   next();
});

// app.use(function(req, res, next) {
//   if(req.session.customer != undefined)
//   res.locals.lang = req.session.customer.lang;
//   next();
// });

// app.get("/changelang/:lang" , function(req,res) {
//   req.session.customer.lang = req.params.lang;
//   res.back();
// });

// app.use(function(req,res,next) {
//   var query = "SELECT * FROM webdetail";
//   DBConnection.query(query,function(err,respond) {
//     if(err) throw err;
//     res.locals.email = respond[0].email;
//     res.locals.contact = respond[0].contact;
//     res.locals.address = respond[0].address;
//   });
//   next();
// });

app.use(function(req, res, next) {
  DBConnection.query("SELECT * FROM orderhistory WHERE status = ?",["n"], function(e, resp){
    if(e) throw e;
    res.locals.orders = resp.length;
    next();
  });
})
// app.use(function(req, res, next) {
//   con.query("SELECT * FROM headers",function(err, resp){
//     var c = resp[0].contact;
//     var em = resp[0].email;
//     res.locals.contact = c;
//     res.locals.mail = em;
//     next();
//   });
//   // next();
// });


app.use(upload());
// Enable body parser post data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//Config view engine
configViewEngine(app);
// app.set("view engine", "ejs");
//Enable flash message
app.use(connectFlash());

//Config passport middleware
// app.use(passport.initialize());
// app.use(passport.session());


// admin area
var adminlogin = require("./routes/admin/login");
app.use('/admin',adminlogin);

// ***********************************************************************

// admin addproduct
var addproduct = require("./routes/admin/addproduct");
app.use("/admin",addproduct);
// end
var orderapprove = require("./routes/admin/orders");
app.use("/admin",orderapprove);
// ************************************* End ******************************
// customer
var customer = require("./routes/admin/customer");
app.use("/admin",customer);
// END
// admin user
var adminuser = require("./routes/admin/admin");
app.use("/admin",adminuser);
// END
// admin details
var details = require("./routes/admin/details");
app.use("/admin",details);
// END
// addcategory
var addcategory = require("./routes/admin/addcategory");
app.use("/admin",addcategory);
// END
var getproduct = require("./routes/admin/getproduct")
app.use("/admin",getproduct);

var front = require("./routes/frontend/home");
app.use("/",front);

var login = require("./routes/frontend/login")
app.use("/",login);


var cart = require("./routes/frontend/shoppingCart");
app.use("/", cart);

app.listen(3000, () => console.log("server started"));
