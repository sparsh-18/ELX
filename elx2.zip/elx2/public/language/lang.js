function langchng() {
  document.cookie = "lang="+document.getElementById('language').innerText;
  if(getCookie("lang") == 'Hindi'){
    document.cookie = "lang=English";
    document.getElementById('language').innerText = 'अंग्रेज़ी';
    document.getElementById('log').innerText = 'लॉग आउट';
  }else{
    document.getElementById('language').innerText = 'Hindi';
    document.getElementById('log').innerText = 'Logout';
  }
}
function getCookie(name) {
    function escape(s) { return s.replace(/([.*+?\^$(){}|\[\]\/\\])/g, '\\$1'); }
    var match = document.cookie.match(RegExp('(?:^|;\\s*)' + escape(name) + '=([^;]*)'));
    return match ? match[1] : null;
}
