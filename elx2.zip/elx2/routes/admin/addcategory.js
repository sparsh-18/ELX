const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');
const path = require('path');
var fs = require("fs");

router.get("/addcategory",function (req,res) {
  var query = "SELECT * FROM category";
  con.query(query,function(err,respond) {
    res.render("admin/addcategory.ejs",{data:respond});
  });
});
router.post("/addcategory",function(req,res) {

  var filename = req.files.prodimg.name;
  let sampleFile = req.files.prodimg;
  var dirpath = "../../public/upload/category/"+filename;
  sampleFile.mv(path.join(__dirname,dirpath), function(err) {
        if (err)
        return res.status(500).send(err);
    });
  var name = req.body.category;
  con.query("INSERT INTO category (name,image) VALUES (?,?)",[name,filename], function(err) {
    if(err) throw err;
    res.redirect("/admin/addcategory");
  });
});
router.post("/catdel",function(req,res) {
  var deleteid = req.body.id;
  con.query("SELECT * FROM category WHERE id = ?", [deleteid] ,function(e, result) {
    fs.unlink("./public/upload/category/"+result[0].image, (err => { 
      if (err) console.log(err);  
      else {
        var query = "DELETE FROM category WHERE id = ?";
        con.query(query,[deleteid], function (err, result) {
         if (err) throw err;
         res.redirect("/admin/addcategory");
       });
      }
    }));
  });
});

module.exports = router;
