const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');

router.get("/",function(req,res) {
  
if(req.session.customer != undefined && req.session.customer!=null) {

   var query = "SELECT * FROM product LIMIT 8";
   con.query(query,function(err,respond) {
     if(err) throw err;
     var query  = "SELECT * FROM category";
     con.query(query,function(err,catdata) {
       if(err) throw err;
       res.render("frontend/home",{data:respond,catdata:catdata});
     });
   });
  } else  {
    res.redirect("/login");
  }
});
// router.get("/demo",function(req,res) {
//   res.render("frontend/demo");
// });
router.get("/category/:name",function(req,res) {
  if(req.params.name == 'all'){
    res.redirect("/");
  }else{
   var cat_name = req.params.name;
   var query = "SELECT * FROM product WHERE category = ? AND name != ?";
   con.query(query,[cat_name,'NA'],function(err,respond) {
     if(err) throw err;
     var query = "SELECT * FROM category";
     con.query(query,function(err,catdata) {
       if(err) throw err;
       res.render("frontend/home",{data:respond,catdata:catdata});
     });
   });
 }
});

module.exports = router;