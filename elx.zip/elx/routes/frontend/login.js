const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');

router.get("/login", function(req, res) {
    res.render("frontend/login.ejs");
});
router.post("/login", function(req,res) {
    req.session.customer = {
        name: req.body.name,
        number: req.body.number,
        // lang: req.body.lang
    };
    res.redirect("/");
});
router.get("/logout", function(req, res) {
    req.session.destroy();
    console.log(req.session);
    res.redirect("/login")
});
module.exports = router;
